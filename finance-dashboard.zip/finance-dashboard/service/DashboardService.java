package com.finance.dashboard.service;

import com.finance.dashboard.model.*;
import com.finance.dashboard.repository.FinancialRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DashboardService {

    @Autowired
    private FinancialRecordRepository repo;

    public double totalIncome() {
        return repo.findByType(RecordType.INCOME)
                .stream().mapToDouble(FinancialRecord::getAmount).sum();
    }

    public double totalExpense() {
        return repo.findByType(RecordType.EXPENSE)
                .stream().mapToDouble(FinancialRecord::getAmount).sum();
    }

    public double balance() {
        return totalIncome() - totalExpense();
    }
}
