package com.finance.dashboard.controller;

import com.finance.dashboard.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/analyst/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService service;

    @GetMapping
    public Map<String, Double> summary() {
        Map<String, Double> map = new HashMap<>();
        map.put("income", service.totalIncome());
        map.put("expense", service.totalExpense());
        map.put("balance", service.balance());
        return map;
    }
}
